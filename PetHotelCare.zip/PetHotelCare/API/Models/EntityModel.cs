﻿namespace PetHotelCare.API.Models
{
    public abstract class EntityModel
    {
        public int Id { get; set; }
    }
}
