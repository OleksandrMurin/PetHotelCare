﻿

namespace PetHotelCare.API.Models
{
    public class FeederModel : EntityModel
    {
        public string FeederSerialNumber { get; set; }
    }
}
