﻿

namespace PetHotelCare.API.Models
{
    public class FoodTypeModel
    {
        public int Id { get; set; }
        public string Name { get; set; } 
        public double PricePer100Grams { get; set; }
    }
}
